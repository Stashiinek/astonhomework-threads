package org.example;

// Это ИЗМЕНЯЕМЫЙ класс
public class Address {
    private String city;

    public Address(String city) {
        this.city = city;
    }

    public Address(Address otherAddress) {
        this.city = otherAddress.city;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    @Override
    public String toString() {
        return "Address{" + "city='" + city + '\'' + '}';
    }
}