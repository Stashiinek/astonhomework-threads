package org.example;

// Это НЕИЗМЕНЯЕМЫЙ класс
public final class Person {
    private final String name;
    private final Address address;

    public Person(String name, Address address) {
        this.name = name;
        this.address = new Address(address);
    }

    public String getName() {
        return name;
    }

    public Address getAddress() {
        return new Address(this.address);
    }

    @Override
    public String toString() {
        return "Person{name='" + name + "', address=" + address + "}";
    }
}